<!DOCTYPE html>
<html lang="ru" data-theme="__THEME__">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<meta name="description" content="__DESC__">
<meta name="theme-color" content="#ffffff">
<meta name="color-scheme" content="light">
<title>Argent VPN — __TITLE__</title>
__FAVICON__
<style>
:root,html[data-theme="light"]{
  color-scheme:light;
  --bg:#fff;
  --text:#171717;
  --muted:#8a8a93;
  --muted2:#66666f;
  --line:#e7e7e7;
  --line-soft:#f0f0f0;
  --green:#20bf91;
  --green-dark:#119b76;
  --yellow:#f5b822;
  --orange:#f07b36;
  --red:#ef5d62;
  --grey:#d8dde3;
  --issue-bg:#fff5c9;
  --issue-line:#f2b300;
}
*{box-sizing:border-box}
html{background:#fff;overflow-y:scroll;scrollbar-gutter:stable}
body{
  margin:0;
  background:#fff;
  color:var(--text);
  font-family:Inter,ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
  -webkit-font-smoothing:antialiased;
  text-rendering:optimizeLegibility;
}
button{font:inherit}
.wrap{width:min(100% - 36px,700px);margin:0 auto;padding:28px 0 48px}
.top{height:54px;display:flex;align-items:flex-start;justify-content:space-between;gap:18px;margin-bottom:15px}
.brand{display:flex;align-items:center;height:38px;min-width:0}
.wordmark{font-size:28px;line-height:1;font-weight:700;letter-spacing:-1.05px;color:#111;white-space:nowrap}
.top-action{display:inline-flex;align-items:center;justify-content:center;min-height:36px;border:0;border-radius:7px;background:#242428;color:#fff;font-size:14px;font-weight:550;line-height:1.2;padding:9px 14px;white-space:nowrap;}
.top-action.issue{background:#242428}
.issue-box{display:none;border:1px solid var(--issue-line);border-radius:9px;overflow:hidden;margin-bottom:24px;background:#fff}
.issue-head{display:flex;align-items:center;gap:10px;padding:18px 17px;background:var(--issue-bg);font-size:16px;font-weight:650;letter-spacing:-.15px}.issue-head>span:last-child{white-space:nowrap}
.warn-icon{width:16px;height:16px;display:inline-grid;place-items:center;flex:none;color:#f4b516;font-size:17px;line-height:1}
.issue-tags{display:flex;gap:8px;flex-wrap:wrap;padding:16px 17px;border-bottom:1px solid var(--line-soft)}
.issue-tag{background:#fff3c2;color:#885014;border-radius:5px;padding:5px 10px;font-size:13px;font-weight:550}
.incident{padding:18px 17px 17px}
.incident+.incident{border-top:1px solid var(--line-soft)}
.incident-title{display:flex;gap:10px;align-items:flex-start;font-size:14px;font-weight:600;line-height:1.45}
.incident-body{margin:8px 0 0 26px;color:#2f2f32;font-size:14px;line-height:1.45}
.incident-meta{margin:10px 0 0 26px;color:var(--muted);font-size:13px;line-height:1.4}
.incident-updates{margin:8px 0 0 26px;display:flex;flex-direction:column;gap:5px}
.incident-update{color:var(--muted2);font-size:12.5px;line-height:1.45}
.status-card{border:1px solid #e4e4e4;border-radius:9px;overflow:hidden;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,.035)}
.status-head{min-height:54px;display:flex;align-items:center;gap:18px;padding:0 17px;border-bottom:1px solid var(--line-soft)}
.status-title{font-size:16px;font-weight:600;letter-spacing:-.15px;white-space:nowrap}
.status-range{display:flex;align-items:center;gap:8px;color:#9b9ba4;font-size:13px;min-width:0;white-space:nowrap}
.range-arrow{font-size:20px;color:#c3c3c8;font-weight:300;line-height:1;transform:translateY(-1px)}
#list{background:#fff}
.group{background:#fff}
.group+.group{border-top:1px solid var(--line-soft)}
.group-main{padding:17px 17px 16px;cursor:default;transition:background .12s}
.group.expandable .group-main{cursor:pointer}
.group.expandable .group-main:hover{background:#fcfcfc}
.group-topline{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:14px;margin-bottom:11px}
.group-label{display:flex;align-items:center;gap:9px;min-width:0}
.state-icon{width:17px;height:17px;display:inline-grid;place-items:center;border-radius:50%;background:var(--green);color:#fff;flex:none;font-size:11px;font-weight:800;line-height:1}
.state-icon.warn{background:transparent;color:#f5b822;border-radius:0;font-size:16px}
.state-icon.bad{background:var(--red);font-size:12px}
.flag{width:22px;height:15px;border-radius:2px;object-fit:cover;border:1px solid rgba(0,0,0,.1);flex:none;background:#f5f5f5}
.country{font-size:14px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.info-dot{width:14px;height:14px;border:1px solid #c6c6cb;border-radius:50%;display:inline-grid;place-items:center;color:#9b9ba1;font-size:9px;font-weight:700;flex:none}
.server-count{color:#8f8f98;font-size:13px;white-space:nowrap}
.chev{display:inline-block;width:7px;height:7px;border-right:1.5px solid #a7a7ae;border-bottom:1.5px solid #a7a7ae;transform:rotate(45deg) translateY(-2px);margin-left:1px;transition:transform .15s}
.group.open .chev{transform:rotate(225deg) translate(-1px,-1px)}
.group-uptime{color:#96969e;font-size:13px;white-space:nowrap;text-align:right}
.group-uptime strong{font-weight:500;color:#96969e}
.bars{width:100%;height:18px;display:block;overflow:visible}
.bars rect{shape-rendering:geometricPrecision}
.components{display:none;border-top:1px solid var(--line-soft);background:#fbfbfb}
.group.open .components{display:block}
.component{padding:13px 17px 13px 43px}
.component+.component{border-top:1px solid #ededed}
.component-top{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;align-items:center;margin-bottom:9px}
.component-name{font-size:13px;font-weight:540;color:#3e3e42;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.component-status{font-size:12.5px;color:#929299;white-space:nowrap}
.component-status.online{color:var(--green-dark)}
.component-status.offline{color:var(--red)}
.empty{padding:34px 18px;text-align:center;color:var(--muted);font-size:14px}
.legend{display:flex;align-items:center;gap:13px;flex-wrap:wrap;padding:12px 2px 0;color:#9999a0;font-size:11.5px}
.legend span{white-space:nowrap}
.legend i{width:9px;height:9px;border-radius:2px;display:inline-block;margin-right:5px;vertical-align:-1px}
.history-wrap{text-align:center;margin-top:24px}
.history-btn{display:inline-flex;align-items:center;gap:8px;border:1px solid #d9d9dc;border-radius:7px;background:#fff;color:#222;font-size:13.5px;font-weight:540;padding:9px 13px;cursor:pointer;box-shadow:0 1px 1px rgba(0,0,0,.02)}
.history-btn:hover{background:#fafafa}
.calendar-icon{width:14px;height:14px;border:1.7px solid #222;border-radius:2px;display:inline-block;position:relative}
.calendar-icon:before{content:"";position:absolute;left:2px;right:2px;top:3px;border-top:1.5px solid #222}
.foot{margin-top:28px;text-align:center;color:#a1a1a8;font-size:12px;line-height:1.55}
.foot-brand{font-size:13px;color:#8f8f96;margin-bottom:14px}.foot-brand strong{color:#77777e;font-weight:650}
#tip{position:fixed;z-index:100;pointer-events:none;opacity:0;transition:opacity .08s;background:#fff;border:1px solid #ddd;border-radius:7px;box-shadow:0 8px 25px rgba(0,0,0,.12);padding:9px 10px;font-size:12px;color:#333;min-width:130px}
#tip .d{font-weight:650;margin-bottom:4px}#tip .k{color:#777;line-height:1.5}
@media(max-width:640px){
  .wrap{width:min(100% - 24px,700px);padding-top:20px}.wordmark{font-size:25px}.top{height:auto;align-items:center;margin-bottom:18px}.top-action{font-size:12.5px;padding:9px 11px}
  .status-head{align-items:flex-start;flex-direction:column;gap:6px;padding:14px 14px}.group-main{padding:15px 14px}.group-topline{gap:8px}.server-count{font-size:12px}.group-uptime{font-size:12px}.flag{width:21px}.component{padding-left:40px;padding-right:14px}
  .issue-head,.issue-tags,.incident{padding-left:14px;padding-right:14px}.issue-head>span:last-child{white-space:normal}.incident-body,.incident-meta,.incident-updates{margin-left:25px}
}
@media(max-width:430px){.server-count{display:none}.info-dot{display:none}.top-action{max-width:165px;overflow:hidden;text-overflow:ellipsis}.status-range{font-size:12px}.component-name{max-width:220px}}
</style>
</head>
<body>
<div class="wrap">
  <header class="top">
    <div class="brand"><div class="wordmark">Argent VPN</div></div>
    <div id="overall" class="top-action">Проверяем статус…</div>
  </header>

  <main>
    <section id="incidents" class="issue-box" aria-live="polite"></section>

    <section class="status-card" id="system-status" aria-label="Состояние системы">
      <div class="status-head">
        <div class="status-title">Состояние системы</div>
        <div class="status-range"><span class="range-arrow">‹</span><span id="range">Последние __DAYS__ дней</span><span class="range-arrow">›</span></div>
      </div>
      <div id="list"><div class="empty">Загрузка данных…</div></div>
    </section>

    <div class="legend" aria-label="Легенда">
      <span><i style="background:#20bf91"></i>в норме</span>
      <span><i style="background:#f5b822"></i>краткий сбой</span>
      <span><i style="background:#f07b36"></i>заметный сбой</span>
      <span><i style="background:#ef5d62"></i>длительный сбой</span>
      <span><i style="background:#d8dde3"></i>нет данных</span>
    </div>

    <div class="history-wrap"><button id="history" class="history-btn" type="button"><span class="calendar-icon"></span><span>Показать серверы</span></button></div>

    <footer class="foot">
      <div class="foot-brand">Статус инфраструктуры <strong>Argent VPN</strong></div>
      <div id="foot">Данные обновляются автоматически.</div>
    </footer>
  </main>
</div>
<div id="tip"></div>
<script>
var GREY="#d8dde3", GREEN="#20bf91", YELLOW="#f5b822", ORANGE="#f07b36", RED="#ef5d62";
var SVGNS="http://www.w3.org/2000/svg";
var tip=document.getElementById("tip");
var lastData=null;

function escapeHtml(s){var d=document.createElement("div");d.textContent=s==null?"":String(s);return d.innerHTML;}
function pad2(n){return ("0"+n).slice(-2);}
function localHM(ts){var d=new Date(ts*1000);return pad2(d.getHours())+":"+pad2(d.getMinutes());}
function localSmart(ts){var d=new Date(ts*1000);return pad2(d.getDate())+"."+pad2(d.getMonth()+1)+" "+pad2(d.getHours())+":"+pad2(d.getMinutes());}
function fmtDur(m){if(!m||m<=0)return "0 мин";if(m>=1440){var dd=Math.floor(m/1440),h=Math.round((m%1440)/60);return dd+" дн"+(h?" "+h+" ч":"");}if(m>=60){var hh=Math.floor(m/60),mm=m%60;return hh+" ч"+(mm?" "+mm+" мин":"");}return m+" мин";}
function pluralServers(n){var n10=n%10,n100=n%100;if(n10===1&&n100!==11)return n+" сервер";if(n10>=2&&n10<=4&&(n100<12||n100>14))return n+" сервера";return n+" серверов";}
function countryFromName(name){var s=(name||"").trim();var p=s.indexOf("|");if(p>=0)s=s.slice(0,p).trim();return s||"Серверы";}
function componentFromName(name,country){var s=(name||"").trim();var p=s.indexOf("|");if(p>=0){s=s.slice(p+1).trim();if(s)return s;}if(s===country)return "Основной сервер";return s||"Сервер";}
function mean(vals){var a=vals.filter(function(v){return typeof v==="number"&&!isNaN(v);});if(!a.length)return null;return a.reduce(function(x,y){return x+y;},0)/a.length;}
function formatUptime(v){return v==null?"—":v.toFixed(2)+"% аптайм";}
function dayColor(d){if(!d||!d.hasData)return GREY;if((d.downMin||0)<=0)return GREEN;if(d.downMin<=30)return YELLOW;if(d.downMin<120)return ORANGE;return RED;}
function groupDay(members,index){var ds=members.map(function(s){return s.days&&s.days[index];}).filter(Boolean);if(!ds.length)return {hasData:false,downMin:0,uptime:null,label:""};var withData=ds.filter(function(d){return d.hasData;});if(!withData.length)return {hasData:false,downMin:0,uptime:null,label:ds[0].label||""};return {hasData:true,downMin:Math.max.apply(null,withData.map(function(d){return d.downMin||0;})),uptime:mean(withData.map(function(d){return d.uptime;})),label:withData[0].label||""};}
function barsSVG(days,klass){var n=Math.max(days.length,1),gap=4,w=1000/n;var rects=days.map(function(d,i){var x=i*w+gap/2,ww=Math.max(3,w-gap);return '<rect data-i="'+i+'" x="'+x.toFixed(2)+'" y="0" width="'+ww.toFixed(2)+'" height="100" rx="2.5" fill="'+dayColor(d)+'"></rect>';}).join("");return '<svg class="bars '+(klass||"")+'" viewBox="0 0 1000 100" preserveAspectRatio="none" aria-hidden="true">'+rects+'</svg>';}
function statusIcon(group){var online=group.members.filter(function(s){return s.online;}).length;var hasIncident=group.members.some(function(s){return !s.online;});var u=mean(group.members.map(function(s){return s.uptime30;}));if(hasIncident||online<group.members.length)return '<span class="state-icon bad">×</span>';if(u!=null&&u<99.9)return '<span class="state-icon warn">▲</span>';return '<span class="state-icon">✓</span>';}
function serverCC(s){return (s.cc||"xx").toLowerCase();}
function groupServers(servers){var groups=[],by={};(servers||[]).forEach(function(s){var cc=serverCC(s),country=countryFromName(s.name),key=cc!=="xx"?cc:("name:"+country.toLowerCase());if(!by[key]){by[key]={key:key,cc:cc,country:country,members:[]};groups.push(by[key]);}by[key].members.push(s);});return groups;}
function moveTip(e){var w=tip.offsetWidth,x=e.clientX+12,y=e.clientY-10;if(x+w>window.innerWidth-8)x=e.clientX-w-12;tip.style.left=x+"px";tip.style.top=Math.max(8,y)+"px";}
function hideTip(){tip.style.opacity="0";}
function showDayTip(e,d){var ut=d&&d.uptime!=null?d.uptime.toFixed(2)+"%":"нет данных";var down=d&&d.hasData?((d.downMin||0)>0?"простой: "+fmtDur(d.downMin):"сбоев нет"):"нет данных";tip.innerHTML='<div class="d">'+escapeHtml((d&&d.label)||"")+'</div><div class="k">аптайм: <b>'+ut+'</b></div><div class="k">'+down+'</div>';tip.style.opacity="1";moveTip(e);}
function bindBars(root,days){var rs=root.querySelectorAll(".bars rect");for(var i=0;i<rs.length;i++){(function(r,d){r.addEventListener("mouseenter",function(e){showDayTip(e,d);});r.addEventListener("mousemove",moveTip);r.addEventListener("mouseleave",hideTip);})(rs[i],days[i]);}}
function groupUptime(g){return mean(g.members.map(function(s){return s.uptime30;}));}
function groupDays(g){var max=0;g.members.forEach(function(s){max=Math.max(max,(s.days||[]).length);});var out=[];for(var i=0;i<max;i++)out.push(groupDay(g.members,i));return out;}
function renderList(data){
  var list=document.getElementById("list"),groups=groupServers(data.servers||[]);list.innerHTML="";
  if(!groups.length){list.innerHTML='<div class="empty">Серверы пока не обнаружены.</div>';return;}
  groups.forEach(function(g){
    var gd=groupDays(g),up=groupUptime(g),expandable=g.members.length>1;
    var box=document.createElement("div");box.className="group"+(expandable?" expandable":"");box.dataset.key=g.key;
    var flag='<img class="flag" src="/flags/'+escapeHtml(g.cc)+'.svg" alt="" loading="lazy">';
    box.innerHTML='<div class="group-main" role="'+(expandable?'button':'group')+'" '+(expandable?'tabindex="0" aria-expanded="false"':'')+'><div class="group-topline"><div class="group-label">'+statusIcon(g)+flag+'<span class="country">'+escapeHtml(g.country)+'</span><span class="info-dot">i</span><span class="server-count">'+pluralServers(g.members.length)+'</span>'+(expandable?'<span class="chev"></span>':'')+'</div><div class="group-uptime">'+formatUptime(up)+'</div></div>'+barsSVG(gd,"group-bars")+'</div><div class="components"></div>';
    var comps=box.querySelector(".components");
    if(expandable){g.members.forEach(function(s){var c=document.createElement("div");c.className="component";c.innerHTML='<div class="component-top"><div class="component-name">'+escapeHtml(componentFromName(s.name,g.country))+'</div><div class="component-status '+(s.online?'online':'offline')+'">'+(s.maintenance?'Обслуживание':(s.online?'Работает':'Недоступен'))+' · '+(s.uptime30==null?'—':s.uptime30.toFixed(2)+'%')+'</div></div>'+barsSVG(s.days||[],"component-bars");comps.appendChild(c);bindBars(c,s.days||[]);});}
    var main=box.querySelector(".group-main");bindBars(main,gd);
    if(expandable){var toggle=function(){var open=box.classList.toggle("open");main.setAttribute("aria-expanded",open?"true":"false");syncHistoryButton();};main.addEventListener("click",function(e){if(e.target.closest(".bars"))return;toggle();});main.addEventListener("keydown",function(e){if(e.key==="Enter"||e.key===" "){e.preventDefault();toggle();}});}
    list.appendChild(box);
  });
}
function incidentStatus(s){return ({investigating:"Расследуем",identified:"Причина найдена",monitoring:"Наблюдаем",resolved:"Устранено"})[s]||s||"Обновление";}
function renderIncidents(data){
  var el=document.getElementById("incidents"),incs=(data&&data.incidents)||[];
  if(!incs.length){el.style.display="none";el.innerHTML="";return;}
  var tags=[],seen={};incs.forEach(function(i){(i.affected||[]).forEach(function(a){var n=typeof a==="string"?countryFromName(a):countryFromName(a.name||"");if(n&&!seen[n]){seen[n]=1;tags.push(n);}});});
  var html='<div class="issue-head"><span class="warn-icon">▲</span><span>Сейчас наблюдаются проблемы</span></div>';
  if(tags.length)html+='<div class="issue-tags">'+tags.map(function(t){return '<span class="issue-tag">'+escapeHtml(t)+'</span>';}).join("")+'</div>';
  incs.forEach(function(i){var latest=(i.updates&&i.updates.length)?i.updates[i.updates.length-1]:null;var body=latest&&latest.body&&latest.body!=="статус обновлён"?latest.body:"Мы работаем над восстановлением стабильной работы сервиса.";var meta=incidentStatus(i.status)+(i.startedTs?' · началось '+localSmart(i.startedTs):'');var updates='';if(i.updates&&i.updates.length>1){updates='<div class="incident-updates">'+i.updates.slice(-3).reverse().map(function(u){return '<div class="incident-update">'+localSmart(u.ts)+' · '+escapeHtml(incidentStatus(u.status))+(u.body&&u.body!=="статус обновлён"?' — '+escapeHtml(u.body):'')+'</div>';}).join("")+'</div>';}
    html+='<div class="incident"><div class="incident-title"><span class="warn-icon">▲</span><span>'+escapeHtml(i.title||"Проблема с доступностью")+'</span></div><div class="incident-body">'+escapeHtml(body)+'</div><div class="incident-meta">'+escapeHtml(meta)+'</div>'+updates+'</div>';});
  el.innerHTML=html;el.style.display="block";
}
function updateHeader(data){
  document.title="Argent VPN"+(data.title?" — "+data.title:"");
  var incidents=(data.incidents||[]).length,tot=data.totals||{},allUp=tot.total>0&&tot.online===tot.total&&!incidents;
  var overall=document.getElementById("overall");overall.textContent=allUp?"Все системы в норме":(incidents?"Есть активные проблемы":((tot.total>0&&tot.online<tot.total)?"Есть недоступные серверы":"Проверяем состояние"));overall.className="top-action"+(incidents?" issue":"");
  var days=data.days||__DAYS__,groups=groupServers(data.servers||[]);var first=null,last=null;if(groups.length){var gd=groupDays(groups[0]);if(gd.length){first=gd[0].label;last=gd[gd.length-1].label;}}
  document.getElementById("range").textContent=(first&&last)?first+" — "+last:"Последние "+days+" дней";
  var f=document.getElementById("foot"),parts=[];if(data.lastCheckTs)parts.push("Последняя проверка: "+localSmart(data.lastCheckTs));if(data.pollInterval)parts.push("обновление раз в "+Math.max(1,Math.round(data.pollInterval/60))+" мин");f.textContent=parts.length?parts.join(" · "):"Данные обновляются автоматически.";
}
function syncHistoryButton(){var btn=document.getElementById("history"),gs=[].slice.call(document.querySelectorAll(".group.expandable"));if(!gs.length){btn.style.display="none";return;}btn.style.display="inline-flex";var all=gs.every(function(g){return g.classList.contains("open");});btn.querySelector("span:last-child").textContent=all?"Скрыть серверы":"Показать серверы";}
function render(data){lastData=data;updateHeader(data);renderIncidents(data);renderList(data);syncHistoryButton();}
function load(){fetch("api/summary").then(function(r){if(!r.ok)throw new Error("http "+r.status);return r.json();}).then(function(d){if(!d||!d.servers)throw new Error("bad payload");render(d);}).catch(function(){var list=document.getElementById("list");if(!list.querySelector(".group"))list.innerHTML='<div class="empty">Не удалось обновить данные. Повторяем попытку…</div>';});}
document.getElementById("history").addEventListener("click",function(){var gs=[].slice.call(document.querySelectorAll(".group.expandable"));var shouldOpen=gs.some(function(g){return !g.classList.contains("open");});gs.forEach(function(g){g.classList.toggle("open",shouldOpen);var m=g.querySelector(".group-main");if(m)m.setAttribute("aria-expanded",shouldOpen?"true":"false");});syncHistoryButton();});
load();
setInterval(function(){if(!document.hidden)load();},60000);
document.addEventListener("visibilitychange",function(){if(!document.hidden)load();});
</script>
</body>
</html>

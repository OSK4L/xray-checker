# Обновление Argent VPN Statuspage

Эта сборка добавляет OpenAI-подобную анимацию раскрытия групп стран: при раскрытии страны статусная галочка в заголовке плавно исчезает, агрегированная шкала/аптайм сворачиваются, а список серверов плавно появляется. При закрытии анимация выполняется в обратную сторону.

## Безопасное обновление текущей установки

Предполагается текущая схема:
- контейнер приложения: `xray-statuspage`
- образ: `xray-statuspage-custom`
- сеть: `xray-checker-statuspage-go-build_default`
- volume `/data`: `xray-checker-statuspage-go-build_status_data`
- env-файл: `/opt/xray-checker/statuspage.env`
- PostgreSQL: `xray-db`

### 1. Резервная копия PostgreSQL

```bash
mkdir -p /opt/xray-checker/backup
docker exec xray-db pg_dump -U statuspage statuspage | gzip > /opt/xray-checker/backup/statuspage-$(date +%F-%H%M).sql.gz
```

### 2. Распаковка релиза

```bash
mkdir -p /opt/xray-checker/releases/openai-v3
cd /opt/xray-checker/releases/openai-v3
unzip -o /opt/xray-checker/argent-vpn-statuspage-openai-v3.zip
cd xray-checker-statuspage-go-build
```

### 3. Сборка нового образа без остановки текущего контейнера

```bash
docker build --no-cache \
  --build-arg VERSION=argent-openai-v3 \
  -t xray-statuspage-custom:openai-v3 \
  .
```

### 4. Замена только statuspage

```bash
docker stop xray-statuspage
docker rename xray-statuspage xray-statuspage-prev

docker run -d \
  --name xray-statuspage \
  --restart unless-stopped \
  --network xray-checker-statuspage-go-build_default \
  -p 127.0.0.1:8081:80 \
  --env-file /opt/xray-checker/statuspage.env \
  -v xray-checker-statuspage-go-build_status_data:/data \
  xray-statuspage-custom:openai-v3
```

### 5. Проверка

```bash
docker logs xray-statuspage --tail 100
curl -I http://127.0.0.1:8081/
docker inspect xray-statuspage --format '{{range .Config.Env}}{{println .}}{{end}}' | grep -E '^DB_DRIVER=|^DB_DSN=|^CHECKER_URL='
docker exec xray-db psql -U statuspage -d statuspage -c 'SELECT COUNT(*) FROM samples;'
```

После проверки сайта сделайте `Ctrl+Shift+R` в браузере.

### 6. Если всё работает

```bash
docker tag xray-statuspage-custom:openai-v3 xray-statuspage-custom:latest
docker rm xray-statuspage-prev
```

### Откат

```bash
docker rm -f xray-statuspage
docker rename xray-statuspage-prev xray-statuspage
docker start xray-statuspage
```

Не используйте `docker compose down -v`, `docker system prune --volumes` и не удаляйте PostgreSQL volume.

<!DOCTYPE html>
<html lang="ru" data-theme="__THEME__">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<meta name="description" content="__DESC__">
<meta name="theme-color" content="#ffffff">
<meta name="color-scheme" content="light">
<title>Argent VPN — __TITLE__</title>
__FAVICON__
<style>
:root,html[data-theme="light"]{
  color-scheme:light;
  --page:#fff;
  --ink:#15171c;
  --button:#29292f;
  --muted:#707070;
  --muted-2:#8f8f98;
  --border:#e4e4e7;
  --divider:#f1f1f2;
  --green:#24c19a;
  --green-soft:#d8f8f0;
  --yellow:#fbbf24;
  --yellow-soft:#fff3c4;
  --orange:#fb7a39;
  --red:#ff7557;
  --grey:#dfe3e8;
}
*{box-sizing:border-box}
html{background:var(--page);overflow-y:scroll;scrollbar-gutter:stable}
body{
  margin:0;
  min-height:100vh;
  background:#fff;
  color:var(--ink);
  font-family:Inter,ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  font-size:14px;
  -webkit-font-smoothing:antialiased;
  text-rendering:optimizeLegibility;
}
button{font:inherit}
.shell{width:min(100% - 32px,718px);margin:0 auto;padding:16px 0 56px}
.page{padding:8px 16px 0}
.header{min-height:36px;display:flex;align-items:center;justify-content:space-between;gap:20px;margin:0 0 24px}
.brand{display:flex;align-items:center;height:28px;color:#0d0d0d;text-decoration:none}
.wordmark{font-size:24px;line-height:1;font-weight:650;letter-spacing:-.8px;white-space:nowrap}
.refresh-btn{
  border:0;border-radius:6px;background:var(--button);color:#fff;
  font-size:14px;line-height:20px;font-weight:520;padding:7px 11px;
  cursor:pointer;transition:opacity .15s,transform .15s;white-space:nowrap;
  box-shadow:inset 0 0 0 1px rgba(0,0,0,.12);
}
.refresh-btn:hover{opacity:.9}.refresh-btn:active{transform:translateY(1px)}.refresh-btn[disabled]{opacity:.6;cursor:wait}
.card{border:1px solid var(--border);border-radius:8px;background:#fff;overflow:hidden;box-shadow:0 1px 2px rgba(0,0,0,.035)}
.summary-card{margin-bottom:24px;border-color:var(--green)}
.summary-card.issue{border-color:var(--yellow)}
.summary-head{
  display:flex;align-items:center;gap:10px;min-height:64px;padding:18px 16px;
  background:var(--green-soft);font-size:16px;line-height:22px;font-weight:600;
}
.summary-card.issue .summary-head{background:var(--yellow-soft)}
.status-icon{width:16px;height:16px;display:inline-grid;place-items:center;flex:none;color:var(--green)}
.status-icon svg{display:block;width:16px;height:16px}.summary-card.issue .status-icon{color:var(--yellow)}
.summary-body{border-top:1px solid rgba(36,193,154,.08);padding:19px 16px 20px;font-size:14px;line-height:1.5;color:var(--ink);background:#fff}
.summary-card.issue .summary-body{border-top-color:rgba(251,191,36,.16)}
.issue-tags{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:13px}
.issue-tag{display:inline-flex;align-items:center;border:1px solid #f0d487;background:#fff9e8;border-radius:4px;padding:4px 8px;color:#8a5b00;font-size:12px;font-weight:540}
.incident+.incident{border-top:1px solid #f4ecd8;margin-top:14px;padding-top:14px}.incident-title{font-weight:590;margin-bottom:5px}.incident-copy{color:#3b3b42}.incident-meta{margin-top:7px;color:var(--muted-2);font-size:12.5px}
.system-card{margin-bottom:0}
.system-head{min-height:60px;padding:15px 16px;display:flex;align-items:center;border-bottom:1px solid var(--divider)}
.system-head-left{display:flex;align-items:center;gap:16px;min-width:0}.system-title{font-size:16px;line-height:22px;font-weight:590;white-space:nowrap}
.date-nav{display:flex;align-items:center;gap:4px;color:#9a9aa2;font-size:13px;white-space:nowrap}.nav-icon{width:16px;height:16px;display:grid;place-items:center;color:#d2d2d8}.nav-icon.active{color:#9d9da5}.nav-icon svg{width:16px;height:16px;display:block}
.row{padding:13px 16px 14px;background:#fff}.row+.row{border-top:1px solid var(--divider)}.group-main{cursor:default}.group.expandable .group-main{cursor:pointer}.group.expandable .row:hover{background:#fefefe}
.row-top{height:28px;display:flex;align-items:center;min-width:0;margin-bottom:7px;transition:margin-bottom .22s cubic-bezier(.4,0,.2,1)}
.row-state{width:16px;height:16px;margin-right:9px;display:grid;place-items:center;flex:none;color:var(--green);overflow:hidden;opacity:1;transform:translateX(0) scale(1);transform-origin:center;transition:width .22s cubic-bezier(.4,0,.2,1),margin-right .22s cubic-bezier(.4,0,.2,1),opacity .14s ease,transform .22s cubic-bezier(.4,0,.2,1)}
.row-state svg{width:16px;height:16px;display:block;flex:none}.row-state.warn{color:var(--yellow)}.row-state.bad{color:var(--red)}
.group.open .group-main .row-state{width:0;margin-right:0;opacity:0;transform:translateX(-5px) scale(.72);pointer-events:none}
.flag{width:20px;height:14px;border-radius:2px;object-fit:cover;border:1px solid rgba(0,0,0,.07);margin-right:8px;flex:none;background:#fafafa}
.row-name{font-size:14px;line-height:20px;font-weight:570;color:var(--ink);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.info{width:15px;height:15px;margin-left:6px;color:#b4b4bc;flex:none}
.count-toggle{display:flex;align-items:center;color:var(--muted);font-size:13px;margin-left:9px;white-space:nowrap;min-width:0}.chev{width:11px;height:11px;margin:1px 0 0 4px;color:#b6b6bd;transition:transform .15s}.group.open .chev{transform:rotate(180deg)}
.grow{flex:1;min-width:12px}.uptime{color:#92929b;font-size:13px;font-weight:400;white-space:nowrap;margin-left:12px;max-width:150px;overflow:hidden;opacity:1;transition:max-width .22s cubic-bezier(.4,0,.2,1),margin-left .22s cubic-bezier(.4,0,.2,1),opacity .14s ease}
.chart{height:16px;width:100%;display:block;overflow:visible;opacity:1;transition:height .22s cubic-bezier(.4,0,.2,1),opacity .14s ease}.chart rect{shape-rendering:geometricPrecision;transition:opacity .12s}.chart rect:hover{opacity:.76}
.components{max-height:0;opacity:0;overflow:hidden;border-top:0 solid transparent;background:#fff;transform:translateY(-3px);transition:max-height .34s cubic-bezier(.4,0,.2,1),opacity .18s ease,transform .26s cubic-bezier(.4,0,.2,1),border-width .18s ease}
.group.open .components{max-height:4000px;opacity:1;transform:translateY(0);border-top:1px solid var(--divider)}
.group.open .group-main{padding-bottom:10px}.group.open .group-main .chart{height:0;opacity:0;pointer-events:none}.group.open .group-main .uptime{max-width:0;margin-left:0;opacity:0}.group.open .group-main .row-top{margin-bottom:0}
.component{padding:11px 16px 13px}.component+.component{border-top:1px solid var(--divider)}.component-top{display:flex;align-items:center;height:28px;margin-bottom:6px}.component-state{width:16px;height:16px;margin-right:9px;display:grid;place-items:center;flex:none;color:var(--green)}.component-state svg{width:16px;height:16px}.component-state.bad{color:var(--red)}.component-state.warn{color:var(--yellow)}.component-name{font-size:14px;line-height:20px;font-weight:540;color:var(--ink);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.component-uptime{font-size:13px;color:#92929b;white-space:nowrap;margin-left:12px}
.empty{padding:36px 16px;text-align:center;color:var(--muted);font-size:14px}
.actions{display:flex;justify-content:center;margin-top:25px}.history-btn{display:inline-flex;align-items:center;gap:8px;border:1px solid #d5d5da;border-radius:6px;background:#fff;color:#202127;font-size:13.5px;line-height:20px;font-weight:510;padding:8px 11px;cursor:pointer;box-shadow:0 1px 1px rgba(0,0,0,.02)}.history-btn:hover{background:#fafafa}.history-btn svg{width:15px;height:15px;color:#29292f}
.footer{margin-top:28px;text-align:center;color:#9a9aa2;font-size:12px;line-height:18px}.footer-brand{margin-bottom:13px;font-size:13px;color:#9a9aa2}.footer-brand strong{font-weight:600;color:#72727a}.footer-copy{max-width:650px;margin:0 auto;color:#9a9aa2}.footer-meta{margin-top:11px;color:#a4a4ac}
#tip{position:fixed;z-index:1000;pointer-events:none;opacity:0;transition:opacity .08s;background:#fff;color:var(--ink);border:1px solid #e0e0e3;border-radius:7px;box-shadow:0 4px 12px rgba(0,0,0,.08);padding:10px 12px;font-size:12px;line-height:1.45;min-width:170px;max-width:260px}#tip .tip-title{font-weight:400;color:#8f8f98;margin-bottom:8px}#tip .tip-line{display:flex;align-items:center;gap:8px;color:#73737c}#tip .tip-state{width:16px;height:16px;display:grid;place-items:center;color:var(--green);flex:none}#tip .tip-state.warn{color:var(--yellow)}#tip .tip-state.bad{color:var(--red)}#tip .tip-state svg{width:16px;height:16px}
@media(prefers-reduced-motion:reduce){.row-state,.row-top,.uptime,.chart,.components,.chev{transition:none!important}}
@media(max-width:640px){.shell{width:min(100% - 20px,718px);padding-top:12px}.page{padding-left:4px;padding-right:4px}.header{margin-bottom:20px}.wordmark{font-size:22px}.refresh-btn{font-size:12.5px;padding:6px 9px}.summary-head{min-height:58px;padding:16px 14px}.summary-body{padding:17px 14px}.system-head{align-items:flex-start;flex-direction:column;gap:4px}.system-head-left{align-items:flex-start;flex-direction:column;gap:5px}.row,.component{padding-left:13px;padding-right:13px}.count-toggle{font-size:12px}.uptime,.component-uptime{font-size:12px}}
@media(max-width:470px){.count-label{display:none}.info{display:none}.uptime{margin-left:7px}.flag{width:19px}.date-nav{font-size:12px}.summary-head{font-size:15px}.footer-copy{font-size:11.5px}}
</style>
</head>
<body>
<div class="shell"><div class="page">
<header class="header">
  <a class="brand" href="/" aria-label="Argent VPN"><span class="wordmark">Argent VPN</span></a>
  <button id="refresh" class="refresh-btn" type="button">Обновить статус</button>
</header>
<main>
  <section id="summaryCard" class="card summary-card" aria-live="polite">
    <div class="summary-head"><span id="summaryIcon" class="status-icon"></span><span id="summaryTitle">Проверяем состояние…</span></div>
    <div id="summaryBody" class="summary-body">Получаем актуальные данные об инфраструктуре Argent VPN.</div>
  </section>

  <section class="card system-card" aria-label="Состояние системы">
    <div class="system-head"><div class="system-head-left">
      <div class="system-title">Состояние системы</div>
      <div class="date-nav" aria-label="Период">
        <span class="nav-icon active" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none"><path d="M15.75 19.5 8.25 12l7.5-7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
        <span id="range">Последние __DAYS__ дней</span>
        <span class="nav-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none"><path d="m8.25 4.5 7.5 7.5-7.5 7.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>
      </div>
    </div></div>
    <div id="list"><div class="empty">Загрузка данных…</div></div>
  </section>

  <div class="actions"><button id="history" class="history-btn" type="button"><svg viewBox="0 0 24 24" fill="none"><path d="M8 2v3M16 2v3M3.5 9h17M5.5 4h13a2 2 0 0 1 2 2v13a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2Z" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg><span>Развернуть все серверы</span></button></div>
  <footer class="footer">
    <div class="footer-brand">Страница состояния <strong>Argent VPN</strong></div>
    <div class="footer-copy">Показатели доступности рассчитываются по результатам автоматических проверок серверов. История отображает состояние инфраструктуры за выбранный период.</div>
    <div id="foot" class="footer-meta">Данные обновляются автоматически</div>
  </footer>
</main>
</div></div>
<div id="tip"></div>
<script>
var GREEN="#24c19a",YELLOW="#fbbf24",ORANGE="#fb7a39",RED="#ff7557",GREY="#dfe3e8";
var tip=document.getElementById("tip"),lastData=null;
var icons={
  ok:'<svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M8 0C3.589 0 0 3.589 0 8s3.589 8 8 8 8-3.589 8-8-3.589-8-8-8Zm3.947 5.641c-1.859 1.382-3.435 3.29-4.683 5.669a.75.75 0 0 1-1.331-.005c-.575-1.117-1.218-2.025-1.965-2.776a.75.75 0 0 1 1.064-1.058c.573.576 1.09 1.228 1.563 1.972 1.239-2.045 2.734-3.726 4.458-5.007a.75.75 0 1 1 .894 1.205Z" fill="currentColor"/></svg>',
  warn:'<svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><path d="M7.13 1.41a1 1 0 0 1 1.74 0l6.52 11.45A1 1 0 0 1 14.52 14H1.48a1 1 0 0 1-.87-1.14L7.13 1.41Z" fill="currentColor"/><path d="M8 5v4.25" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/><circle cx="8" cy="11.45" r=".85" fill="#fff"/></svg>',
  bad:'<svg viewBox="0 0 16 16" fill="none" aria-hidden="true"><circle cx="8" cy="8" r="8" fill="currentColor"/><path d="m5.5 5.5 5 5m0-5-5 5" stroke="#fff" stroke-width="1.5" stroke-linecap="round"/></svg>'
};
function esc(s){var d=document.createElement("div");d.textContent=s==null?"":String(s);return d.innerHTML;}
function localSmart(ts){if(!ts)return "";var d=new Date(ts*1000);return d.toLocaleString("ru-RU",{day:"2-digit",month:"short",hour:"2-digit",minute:"2-digit"});}
function fmtDur(min){min=Math.max(0,Math.round(min||0));if(min<60)return min+" мин";var h=Math.floor(min/60),m=min%60;return h+" ч"+(m?" "+m+" мин":"");}
function pluralServers(n){var m=n%100,d=n%10;return n+" "+(m>=11&&m<=14?"серверов":d===1?"сервер":d>=2&&d<=4?"сервера":"серверов");}
function countryFromName(name){var s=(name||"").replace(/[\u{1F1E6}-\u{1F1FF}]/gu,"").trim();var p=s.indexOf("|");if(p>=0)s=s.slice(0,p).trim();return s||"Серверы";}
function componentFromName(name,country){var s=(name||"").trim(),p=s.indexOf("|");if(p>=0){s=s.slice(p+1).trim();if(s)return s;}if(s===country)return "Основной сервер";return s||"Сервер";}
function mean(vals){var a=vals.filter(function(v){return typeof v==="number"&&!isNaN(v);});if(!a.length)return null;return a.reduce(function(x,y){return x+y;},0)/a.length;}
function formatUptime(v){return v==null?"—":v.toFixed(2)+"% аптайм";}
function dayColor(d){if(!d||!d.hasData)return GREY;if((d.downMin||0)<=0)return GREEN;if(d.downMin<=30)return YELLOW;if(d.downMin<120)return ORANGE;return RED;}
function dayState(d){if(!d||!d.hasData)return "none";if((d.downMin||0)<=0)return "ok";if(d.downMin<120)return "warn";return "bad";}
function groupDay(members,index){var ds=members.map(function(s){return s.days&&s.days[index];}).filter(Boolean);if(!ds.length)return {hasData:false,downMin:0,uptime:null,label:""};var withData=ds.filter(function(d){return d.hasData;});if(!withData.length)return {hasData:false,downMin:0,uptime:null,label:(ds[0]&&ds[0].label)||""};return {hasData:true,downMin:Math.max.apply(null,withData.map(function(d){return d.downMin||0;})),uptime:mean(withData.map(function(d){return d.uptime;})),label:withData[0].label||""};}
function chartSVG(days){var n=Math.max(days.length,1),gap=n>60?2.4:2.8,w=1000/n;var rs=days.map(function(d,i){var x=i*w+gap/2,ww=Math.max(3,w-gap);return '<rect data-i="'+i+'" x="'+x.toFixed(2)+'" y="0" width="'+ww.toFixed(2)+'" height="100" rx="1.5" fill="'+dayColor(d)+'"></rect>';}).join("");return '<svg class="chart" viewBox="0 0 1000 100" preserveAspectRatio="none" aria-hidden="true">'+rs+'</svg>';}
function serverCC(s){return (s.cc||"xx").toLowerCase();}
function groupServers(servers){var groups=[],by={};(servers||[]).forEach(function(s){var cc=serverCC(s),country=countryFromName(s.name),key=cc!=="xx"?cc:("name:"+country.toLowerCase());if(!by[key]){by[key]={key:key,cc:cc,country:country,members:[]};groups.push(by[key]);}by[key].members.push(s);});return groups;}
function groupDays(g){var max=0;g.members.forEach(function(s){max=Math.max(max,(s.days||[]).length);});var out=[];for(var i=0;i<max;i++)out.push(groupDay(g.members,i));return out;}
function groupUptime(g){return mean(g.members.map(function(s){return s.uptime30;}));}
function serverState(s){if(!s.online)return "bad";if(s.maintenance)return "warn";return "ok";}
function groupState(g){if(g.members.some(function(s){return !s.online;}))return "bad";if(g.members.some(function(s){return s.maintenance;}))return "warn";return "ok";}
function moveTip(e){var w=tip.offsetWidth,x=e.clientX+12,y=e.clientY+12;if(x+w>window.innerWidth-8)x=e.clientX-w-12;if(y+tip.offsetHeight>window.innerHeight-8)y=e.clientY-tip.offsetHeight-12;tip.style.left=Math.max(8,x)+"px";tip.style.top=Math.max(8,y)+"px";}
function hideTip(){tip.style.opacity="0";}
function showDayTip(e,d){var st=dayState(d),detail;if(st==="none")detail="Нет данных";else if(st==="ok")detail="Происшествий нет";else detail="Простой: "+fmtDur(d.downMin||0);var icon=st==="none"?"":'<span class="tip-state '+(st==="ok"?"":st)+'">'+icons[st==="bad"?"bad":st==="warn"?"warn":"ok"]+'</span>';tip.innerHTML='<div class="tip-title">'+esc((d&&d.label)||"")+'</div><div class="tip-line">'+icon+'<span>'+esc(detail)+'</span></div>';tip.style.opacity="1";moveTip(e);}
function bindChart(root,days){var rs=root.querySelectorAll(".chart rect");for(var i=0;i<rs.length;i++){(function(r,d){r.addEventListener("mouseenter",function(e){showDayTip(e,d);});r.addEventListener("mousemove",moveTip);r.addEventListener("mouseleave",hideTip);})(rs[i],days[i]);}}
function infoIcon(){return '<svg class="info" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M11.25 11.25l.041-.02a.75.75 0 0 1 1.063.852l-.708 2.836a.75.75 0 0 0 1.063.853l.041-.021M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Zm-9-3.75h.008v.008H12V8.25Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';}
function chevIcon(){return '<svg class="chev" viewBox="0 0 10 6" fill="none" aria-hidden="true"><path d="m9 1-4 4-4-4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';}
function renderList(data){
  var list=document.getElementById("list"),groups=groupServers(data.servers||[]);list.innerHTML="";
  if(!groups.length){list.innerHTML='<div class="empty">Серверы пока не обнаружены.</div>';return;}
  groups.forEach(function(g){
    var gd=groupDays(g),up=groupUptime(g),expandable=g.members.length>1,state=groupState(g),box=document.createElement("div");box.className="group"+(expandable?" expandable":"");box.dataset.key=g.key;
    var flag='<img class="flag" src="/flags/'+esc(g.cc)+'.svg" alt="" loading="lazy">';
    box.innerHTML='<div class="row group-main" role="'+(expandable?'button':'group')+'" '+(expandable?'tabindex="0" aria-expanded="false"':'')+'><div class="row-top"><span class="row-state '+(state==="ok"?"":state)+'">'+icons[state]+'</span>'+flag+'<span class="row-name">'+esc(g.country)+'</span>'+infoIcon()+'<span class="count-toggle"><span class="count-label">'+pluralServers(g.members.length)+'</span>'+(expandable?chevIcon():'')+'</span><span class="grow"></span><span class="uptime">'+formatUptime(up)+'</span></div>'+chartSVG(gd)+'</div><div class="components"></div>';
    var comps=box.querySelector(".components");
    if(expandable){g.members.forEach(function(s){var c=document.createElement("div"),ss=serverState(s);c.className="component";c.innerHTML='<div class="component-top"><span class="component-state '+(ss==="ok"?"":ss)+'">'+icons[ss]+'</span><div class="component-name">'+esc(componentFromName(s.name,g.country))+'</div><span class="grow"></span><div class="component-uptime">'+(s.uptime30==null?'—':s.uptime30.toFixed(2)+'% аптайм')+'</div></div>'+chartSVG(s.days||[]);comps.appendChild(c);bindChart(c,s.days||[]);});}
    var main=box.querySelector(".group-main");bindChart(main,gd);
    if(expandable){var toggle=function(){var open=box.classList.toggle("open");main.setAttribute("aria-expanded",open?"true":"false");syncHistoryButton();};main.addEventListener("click",function(e){if(e.target.closest(".chart"))return;toggle();});main.addEventListener("keydown",function(e){if(e.key==="Enter"||e.key===" "){e.preventDefault();toggle();}});}
    list.appendChild(box);
  });
}
function incidentStatus(s){return ({investigating:"Расследуем",identified:"Причина найдена",monitoring:"Наблюдаем",resolved:"Устранено"})[s]||s||"Обновление";}
function renderSummary(data){
  var incs=(data&&data.incidents)||[],servers=(data&&data.servers)||[],offline=servers.filter(function(s){return !s.online;}),maint=servers.filter(function(s){return s.maintenance;}),card=document.getElementById("summaryCard"),icon=document.getElementById("summaryIcon"),title=document.getElementById("summaryTitle"),body=document.getElementById("summaryBody");
  if(!incs.length&&!offline.length&&!maint.length){card.className="card summary-card";icon.innerHTML=icons.ok;title.textContent="Все системы работают";body.textContent="Нам не известно о проблемах, влияющих на работу систем Argent VPN.";return;}
  card.className="card summary-card issue";icon.innerHTML=icons.warn;title.textContent="Сейчас наблюдаются проблемы";
  var tags=[],seen={};
  incs.forEach(function(i){(i.affected||[]).forEach(function(a){var n=typeof a==="string"?countryFromName(a):countryFromName((a&&a.name)||"");if(n&&!seen[n]){seen[n]=1;tags.push(n);}});});
  offline.concat(maint).forEach(function(s){var n=countryFromName(s.name);if(n&&!seen[n]){seen[n]=1;tags.push(n);}});
  var html=tags.length?'<div class="issue-tags">'+tags.map(function(t){return '<span class="issue-tag">'+esc(t)+'</span>';}).join("")+'</div>':"";
  if(incs.length){incs.forEach(function(i){var latest=(i.updates&&i.updates.length)?i.updates[i.updates.length-1]:null,copy=latest&&latest.body&&latest.body!=="статус обновлён"?latest.body:"Мы работаем над восстановлением стабильной работы сервиса.";html+='<div class="incident"><div class="incident-title">'+esc(i.title||"Проблема с доступностью")+'</div><div class="incident-copy">'+esc(copy)+'</div><div class="incident-meta">'+esc(incidentStatus(i.status)+(i.startedTs?' · с '+localSmart(i.startedTs):''))+'</div></div>';});}
  else {html+='<div class="incident"><div class="incident-title">Обнаружено отклонение в работе серверов</div><div class="incident-copy">Некоторые серверы временно недоступны или находятся на обслуживании. Состояние обновится автоматически после следующей проверки.</div></div>';}
  body.innerHTML=html;
}
function rangeLabel(days,lastCheckTs){var end=lastCheckTs?new Date(lastCheckTs*1000):new Date(),start=new Date(end.getTime()-Math.max(1,days-1)*86400000),fmt=new Intl.DateTimeFormat("ru-RU",{month:"short",year:"numeric"}),a=fmt.format(start).replace(" г.",""),b=fmt.format(end).replace(" г.","");return a===b?a:a+" — "+b;}
function updateMeta(data){document.title="Argent VPN"+(data.title?" — "+data.title:"");document.getElementById("range").textContent=rangeLabel(data.days||__DAYS__,data.lastCheckTs);var foot=document.getElementById("foot"),parts=[];if(data.lastCheckTs)parts.push("Последняя проверка: "+localSmart(data.lastCheckTs));if(data.pollInterval)parts.push("обновление раз в "+Math.max(1,Math.round(data.pollInterval/60))+" мин");foot.textContent=parts.length?parts.join(" · "):"Данные обновляются автоматически";}
function syncHistoryButton(){var btn=document.getElementById("history"),gs=[].slice.call(document.querySelectorAll(".group.expandable"));if(!gs.length){btn.style.display="none";return;}btn.style.display="inline-flex";var all=gs.every(function(g){return g.classList.contains("open");});btn.querySelector("span").textContent=all?"Свернуть серверы":"Развернуть серверы";}
function render(data){lastData=data;renderSummary(data);renderList(data);updateMeta(data);syncHistoryButton();}
function load(){var btn=document.getElementById("refresh");btn.disabled=true;btn.textContent="Обновляем…";fetch("api/summary",{cache:"no-store"}).then(function(r){if(!r.ok)throw new Error("http "+r.status);return r.json();}).then(function(d){if(!d||!d.servers)throw new Error("bad payload");render(d);}).catch(function(){var list=document.getElementById("list");if(!list.querySelector(".group"))list.innerHTML='<div class="empty">Не удалось обновить данные. Повторяем попытку…</div>';}).finally(function(){btn.disabled=false;btn.textContent="Обновить статус";});}
document.getElementById("refresh").addEventListener("click",load);
document.getElementById("history").addEventListener("click",function(){var gs=[].slice.call(document.querySelectorAll(".group.expandable")),open=gs.some(function(g){return !g.classList.contains("open");});gs.forEach(function(g){g.classList.toggle("open",open);var m=g.querySelector(".group-main");if(m)m.setAttribute("aria-expanded",open?"true":"false");});syncHistoryButton();});
load();setInterval(function(){if(!document.hidden)load();},60000);document.addEventListener("visibilitychange",function(){if(!document.hidden)load();});
</script>
</body>
</html>

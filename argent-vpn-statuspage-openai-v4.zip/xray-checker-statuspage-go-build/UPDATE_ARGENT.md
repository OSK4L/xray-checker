# Argent VPN Status — обновление OpenAI animation v4

Версия v4 делает раскрытие групп серверов заметно плавнее: галочка статуса исчезает с мягким сдвигом, агрегированный uptime и график сворачиваются синхронно, а список серверов раскрывается через CSS Grid без резкого скачка высоты.

## 1. Резервная копия PostgreSQL

```bash
mkdir -p /opt/xray-checker/backup
docker exec xray-db pg_dump -U statuspage statuspage | gzip > /opt/xray-checker/backup/statuspage-$(date +%F-%H%M).sql.gz
```

## 2. Распаковать релиз

```bash
mkdir -p /opt/xray-checker/releases/openai-v4
cd /opt/xray-checker/releases/openai-v4
unzip -o /opt/xray-checker/argent-vpn-statuspage-openai-v4.zip
cd xray-checker-statuspage-go-build
```

## 3. Собрать новый образ

```bash
docker build --no-cache --build-arg VERSION=argent-openai-v4 -t xray-statuspage-custom:openai-v4 .
```

## 4. Безопасно освободить имена контейнеров

Если `xray-statuspage-prev` уже существует, сначала сохраните его под уникальным именем:

```bash
if docker container inspect xray-statuspage-prev >/dev/null 2>&1; then
  docker rename xray-statuspage-prev "xray-statuspage-prev-$(date +%Y%m%d-%H%M%S)"
fi
```

Теперь остановите текущую страницу и оставьте её для быстрого отката:

```bash
docker stop xray-statuspage
docker rename xray-statuspage xray-statuspage-prev
```

## 5. Запустить v4

```bash
docker run -d \
  --name xray-statuspage \
  --restart unless-stopped \
  --network xray-checker-statuspage-go-build_default \
  -p 127.0.0.1:8081:80 \
  --env-file /opt/xray-checker/statuspage.env \
  -v xray-checker-statuspage-go-build_status_data:/data \
  xray-statuspage-custom:openai-v4
```

## 6. Проверить

```bash
docker ps --filter name=xray-statuspage
docker logs xray-statuspage --tail 100
curl -I http://127.0.0.1:8081/
docker inspect xray-statuspage --format '{{range .Config.Env}}{{println .}}{{end}}' | grep -E '^DB_DRIVER=|^DB_DSN=|^CHECKER_URL='
docker exec xray-db psql -U statuspage -d statuspage -c 'SELECT COUNT(*) FROM samples;'
```

После открытия сайта выполните `Ctrl+Shift+R`.

## 7. Закрепить версию

```bash
docker tag xray-statuspage-custom:openai-v4 xray-statuspage-custom:latest
```

После проверки можно удалить только контейнер `xray-statuspage-prev`. PostgreSQL/volumes не удалять.

## Откат

```bash
docker rm -f xray-statuspage
docker rename xray-statuspage-prev xray-statuspage
docker start xray-statuspage
```

Не используйте `docker compose down -v`, `docker system prune --volumes` и не удаляйте postgres volume.

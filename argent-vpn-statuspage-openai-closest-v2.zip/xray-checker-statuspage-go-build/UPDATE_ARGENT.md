# Обновление Argent VPN Status Page

Эта сборка меняет только приложение statuspage. PostgreSQL (`xray-db`) и `xray-checker` пересоздавать не требуется.

## 1. Резервная копия PostgreSQL

```bash
mkdir -p /opt/xray-checker/backup
docker exec xray-db pg_dump -U statuspage statuspage | gzip > /opt/xray-checker/backup/statuspage-$(date +%F-%H%M).sql.gz
```

## 2. Собрать новый образ

Из каталога, где находятся `Dockerfile`, `go.mod` и `cmd/`:

```bash
docker build --no-cache \
  --build-arg VERSION=argent-openai-closest-v2 \
  -t xray-statuspage-custom:openai-closest-v2 \
  .
```

## 3. Проверить существующие env, сеть и volume

```bash
ls -lh /opt/xray-checker/statuspage.env

docker network inspect xray-checker-statuspage-go-build_default >/dev/null && echo "network OK"
docker volume inspect xray-checker-statuspage-go-build_status_data >/dev/null && echo "status volume OK"
docker ps | grep xray-db
```

## 4. Сохранить старый контейнер для отката

```bash
docker stop xray-statuspage
docker rename xray-statuspage xray-statuspage-prev
```

## 5. Запустить новую версию

```bash
docker run -d \
  --name xray-statuspage \
  --restart unless-stopped \
  --network xray-checker-statuspage-go-build_default \
  -p 127.0.0.1:8081:80 \
  --env-file /opt/xray-checker/statuspage.env \
  -v xray-checker-statuspage-go-build_status_data:/data \
  xray-statuspage-custom:openai-closest-v2
```

## 6. Проверки

```bash
docker logs xray-statuspage --tail 100
curl -I http://127.0.0.1:8081/

docker inspect xray-statuspage \
  --format '{{range .Config.Env}}{{println .}}{{end}}' \
  | grep -E '^DB_DRIVER=|^DB_DSN=|^CHECKER_URL='

docker exec xray-db \
  psql -U statuspage -d statuspage \
  -c 'SELECT COUNT(*) FROM samples;'
```

После проверки страницы в браузере выполните `Ctrl+Shift+R`.

## 7. Если всё работает

```bash
docker tag xray-statuspage-custom:openai-closest-v2 xray-statuspage-custom:latest
docker rm xray-statuspage-prev
```

## Откат

```bash
docker rm -f xray-statuspage
docker rename xray-statuspage-prev xray-statuspage
docker start xray-statuspage
```

Не удаляйте PostgreSQL volume и не используйте `docker compose down -v` / `docker system prune --volumes` без понимания последствий.

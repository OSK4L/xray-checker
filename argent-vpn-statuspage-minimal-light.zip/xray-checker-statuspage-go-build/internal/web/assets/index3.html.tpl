<!DOCTYPE html>
<html lang="ru" data-theme="__THEME__">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex, nofollow">
<meta name="description" content="__DESC__">
<meta name="theme-color" content="#ffffff">
<meta name="color-scheme" content="light">
<title>Argent VPN — __TITLE__</title>
__FAVICON__
<style>
:root,html[data-theme="light"]{
  color-scheme:light;
  --bg:#ffffff;
  --card:#ffffff;
  --soft:#f7f7f7;
  --line:#dedede;
  --line2:#ececec;
  --hover:#fafafa;
  --tx:#111111;
  --tx2:#5f6368;
  --tx3:#858585;
  --ok:#12a37a;
  --warn:#c98200;
  --orange:#d95d1f;
  --bad:#d9473f;
  --info:#111111;
  --okbg:#eefaf6;
  --warnbg:#fff8e5;
  --badbg:#fff2f0;
  --infobg:#f4f4f4;
}
*{box-sizing:border-box}
html{overflow-y:scroll;scrollbar-gutter:stable;background:#fff;}
body{
  margin:0;
  background:#fff;
  color:var(--tx);
  font-family:ui-sans-serif,-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
  -webkit-font-smoothing:antialiased;
  text-rendering:optimizeLegibility;
  font-feature-settings:"kern" 1,"liga" 1;
}
@keyframes fadeUp{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
.wrap{width:min(100% - 32px,780px);margin:0 auto;padding:26px 0 54px;}
.top{display:flex;align-items:center;justify-content:space-between;gap:18px;min-height:46px;margin-bottom:28px;}
.brand{display:flex;align-items:center;min-width:0;}
.wordmark{font-size:29px;font-weight:700;letter-spacing:-.9px;line-height:1;color:#111;white-space:nowrap;}
.topr{display:flex;align-items:center;gap:10px;}
.pill{display:flex;align-items:center;gap:8px;padding:9px 13px;border-radius:7px;font-size:13.5px;font-weight:600;border:1px solid;white-space:nowrap;line-height:1;}
.pill .dot{width:7px;height:7px;border-radius:50%;display:inline-block;}
.pill.ok{background:#111;color:#fff;border-color:#111;}
.pill.bad{background:var(--badbg);color:#9f2f2a;border-color:#f1aaa5;}
.intro{margin:0 0 20px;padding:0 0 18px;border-bottom:1px solid var(--line2);}
.intro h1{margin:0;font-size:20px;line-height:1.25;font-weight:650;letter-spacing:-.25px;}
.intro p{margin:6px 0 0;color:var(--tx2);font-size:14px;line-height:1.5;}
.stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));border:1px solid var(--line);border-radius:10px;overflow:hidden;margin-bottom:24px;background:#fff;}
.stat{padding:15px 16px;min-width:0;background:#fff;}
.stat+.stat{border-left:1px solid var(--line2);}
.stat .l{font-size:12px;color:var(--tx2);font-weight:500;letter-spacing:0;}
.stat .v{font-size:21px;font-weight:650;margin-top:7px;letter-spacing:-.35px;line-height:1.15;}
.stat .v .vsub{font-size:12px;font-weight:550;color:var(--tx2);margin-left:5px;white-space:nowrap;vertical-align:1px;}
#incidents{display:flex;flex-direction:column;gap:10px;margin:0 0 24px;}
.inc-card{border:1px solid #efb21c;border-radius:9px;padding:14px 16px;background:#fff8d8;}
.inc-card.inc-major{border-color:#e58a42;background:#fff3e8;}
.inc-card.inc-critical{border-color:#e67d76;background:#fff0ef;}
.inc-h{display:flex;gap:9px;align-items:center;font-size:12px;color:#7a5a07;margin-bottom:7px;}
.inc-major .inc-h{color:#8a4615}.inc-critical .inc-h{color:#8f302a}
.inc-sev{font-weight:650}.inc-status{font-weight:550}
.inc-title{font-weight:650;font-size:15px;color:#111;line-height:1.35;}
.inc-time{margin-left:auto;font-size:11.5px;opacity:.8;font-weight:500;white-space:nowrap;}
.inc-aff{margin-top:6px;font-size:12px;color:#5f6368;}
.inc-aff img{width:16px;height:11px;border-radius:2px;object-fit:cover;vertical-align:-1px;margin-right:3px;border:1px solid rgba(0,0,0,.1);}
.inc-tl{margin-top:9px;display:flex;flex-direction:column;gap:5px;border-top:1px solid rgba(0,0,0,.09);padding-top:9px;}
.inc-tlrow{font-size:12px;display:flex;gap:7px;align-items:baseline;flex-wrap:wrap;color:#4f4f4f;}
.inc-tlt{font-variant-numeric:tabular-nums;opacity:.75;min-width:38px;font-weight:500}.inc-tls{font-weight:650;color:#222;}
.servers{margin-top:0;}
.section-head{display:flex;align-items:flex-end;justify-content:space-between;gap:12px;margin:0 0 11px;}
.section-head h2{margin:0;font-size:18px;font-weight:650;letter-spacing:-.2px;color:#111;}
.section-head p{margin:5px 0 0;font-size:13px;color:var(--tx2);}
#list{border:1px solid var(--line);border-radius:10px;overflow:hidden;background:#fff;}
.item{background:#fff;margin:0;overflow:hidden;animation:fadeUp .22s ease both;transition:background .14s;}
.item+.item{border-top:1px solid var(--line2);}
.item:hover{background:var(--hover);}
.row{display:grid;grid-template-columns:220px minmax(220px,1fr) 88px;align-items:center;gap:15px;padding:14px 16px;}
.label{display:flex;align-items:center;gap:10px;min-width:0;}
.flag{width:22px;height:15px;border-radius:2px;object-fit:cover;border:1px solid rgba(0,0,0,.1);flex:none;background:#f7f7f7;}
.nm{min-width:0;}
.name{display:flex;align-items:center;gap:8px;font-size:14px;font-weight:570;min-width:0;}
.name .sdot{width:8px;height:8px;border-radius:50%;flex:none;}
.name span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}
.bars{display:block;height:20px;min-width:0;width:100%;}
.bars rect{transition:fill .2s,opacity .12s;cursor:default;}
.stat2{text-align:right;min-width:0;}
.stat2 .p{font-size:14px;font-weight:650;letter-spacing:-.1px;}
.stat2 .s{font-size:11.5px;color:var(--tx3);margin-top:2px;}
.mnt-line{display:flex;align-items:center;gap:5px;margin-top:3px;font-size:11.5px;color:#616161;font-weight:500;white-space:nowrap;}
.item.maint{background:#fafafa;}.item.maint .bars{opacity:.35}.item.maint .p{color:#555!important;}
.legend{display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-top:12px;font-size:12px;color:var(--tx2);padding:0 2px;}
.legend i{width:10px;height:10px;border-radius:2px;display:inline-block;margin-right:5px;vertical-align:-1px;}
.legend .right{margin-left:auto;color:var(--tx3);}
.foot{margin-top:24px;padding-top:15px;border-top:1px solid var(--line2);font-size:12px;color:var(--tx3);text-align:center;}
#tip{position:fixed;pointer-events:none;opacity:0;transition:opacity .08s;z-index:60;background:#fff;border:1px solid var(--line);border-radius:8px;padding:9px 11px;font-size:12.5px;min-width:140px;box-shadow:0 8px 24px rgba(0,0,0,.11);}
#tip .d{font-weight:650;margin-bottom:4px}#tip .k{color:var(--tx2);line-height:1.5;}
.skel{color:var(--tx2);font-size:14px;padding:30px 0;text-align:center;background:#fff;}
@media (max-width:720px){
  .wrap{width:min(100% - 24px,780px);padding-top:18px;}
  .top{margin-bottom:22px;}.wordmark{font-size:25px;}
  .pill{padding:8px 10px;font-size:12.5px;}
  .row{grid-template-columns:minmax(0,1fr) auto;gap:10px 12px;}
  .bars{grid-column:1/-1;grid-row:2;height:20px;}
  .label{grid-column:1;grid-row:1}.stat2{grid-column:2;grid-row:1;}
  .legend .right{display:none;}
}
@media (max-width:520px){
  .top{align-items:flex-start;flex-direction:column;gap:14px;}
  .stats{grid-template-columns:1fr;}.stat+.stat{border-left:0;border-top:1px solid var(--line2);}
  .inc-time{display:none;}.intro h1{font-size:19px;}
}
</style>
</head>
<body>
<div class="wrap">
  <header class="top">
    <div class="brand"><div class="wordmark">Argent VPN</div></div>
    <div class="topr">
      <div id="overall" class="pill ok"><span class="dot"></span><span>Загрузка...</span></div>
    </div>
  </header>
  <main>
    <section class="intro">
      <h1 id="title">__TITLE__</h1>
      <p id="subtitle">__SUBTITLE__</p>
    </section>
    <section class="stats" aria-label="Сводка">
      <div class="stat"><div class="l">Активные серверы</div><div class="v" id="s-online">—</div></div>
      <div class="stat"><div class="l">Аптайм за __DAYS__ дн</div><div class="v" id="s-uptime">—</div></div>
      <div class="stat"><div class="l">Последняя проверка</div><div class="v" id="s-fresh">—</div></div>
    </section>
    <section id="incidents" aria-live="polite"></section>
    <section class="servers" aria-label="Серверы">
      <div class="section-head">
        <div>
          <h2>Состояние серверов</h2>
          <p>История доступности за последние __DAYS__ дней.</p>
        </div>
      </div>
      <div id="list"><div class="skel">Загрузка данных...</div></div>
      <div class="legend">
        <span><i style="background:#16b07a"></i>норма</span>
        <span><i style="background:#f0a82a"></i>до 30 мин</span>
        <span><i style="background:#e3692f"></i>30 мин – 2 ч</span>
        <span><i style="background:#e8504e"></i>от 2 ч</span>
        <span><i style="background:#cfd6df"></i>нет данных</span>
        <span class="right">← __DAYS__ дней назад · сегодня →</span>
      </div>
    </section>
    <div class="foot" id="foot"></div>
  </main>
</div>
<div id="tip"></div>
<script>
var _compatStyleMarker='style="top:';
function _compatStats(data){return data.stats;}
var GREY="#cfd6df";
var SVGNS="http://www.w3.org/2000/svg";
function colorFor(d){
  if(!d.hasData) return GREY;
  if(d.downMin<=0) return "#16b07a";
  if(d.downMin<=30) return "#f0a82a";
  if(d.downMin<120) return "#e3692f";
  return "#e8504e";
}
function fmtDur(m){
  if(m<=0) return "0 мин";
  if(m>=1440){var dd=Math.floor(m/1440),h=Math.round((m%1440)/60);return dd+" дн"+(h?" "+h+" ч":"");}
  if(m>=60){var h=Math.floor(m/60),mm=m%60;return h+" ч"+(mm?" "+mm+" мин":"");}
  return m+" мин";
}
function pad2(n){return ("0"+n).slice(-2);}
function localHM(ts){var d=new Date(ts*1000);return pad2(d.getHours())+":"+pad2(d.getMinutes());}
function localDateHM(ts){var d=new Date(ts*1000);return d.getFullYear()+"-"+pad2(d.getMonth()+1)+"-"+pad2(d.getDate())+" "+pad2(d.getHours())+":"+pad2(d.getMinutes());}
function localSmart(ts){var d=new Date(ts*1000);return pad2(d.getDate())+"."+pad2(d.getMonth()+1)+" "+pad2(d.getHours())+":"+pad2(d.getMinutes());}
function fmtTime(ts,ds){return localHM(ts);}
function maintLabel(s){
  if(!s.maintenance)return "";
  var t="на обслуживании";
  if(s.maintTo&&s.maintTo>0)t+=" · до "+localSmart(s.maintTo);
  return t;
}
function escapeHtml(s){var d=document.createElement("div");d.textContent=s;return d.innerHTML;}
var tip=document.getElementById("tip");
function evXY(e){var t=e.touches&&e.touches[0];return t||e;}
function moveTip(e){
  e=evXY(e);
  var w=tip.offsetWidth,x=e.clientX+14,y=e.clientY-10;
  if(x+w>window.innerWidth-8)x=e.clientX-w-14;
  tip.style.left=x+"px";tip.style.top=Math.max(8,y)+"px";
}
function hideTip(){tip.style.opacity="0";}
function showTipDay(e,d){
  var u=d.uptime;
  var uc=(u===null)?"var(--tx2)":(u>=99.99?"var(--ok)":(u>=95?"var(--warn)":"var(--bad)"));
  var ut=(u===null)?"нет данных":u.toFixed(2)+"%";
  var down=!d.hasData?''
    :d.downMin>0?'<div class="k">простой: <b style="color:var(--bad)">'+fmtDur(d.downMin)+'</b></div>'
    :((d.uptime!==null&&d.uptime<100)?'<div class="k">кратковременный сбой</div>':'<div class="k">сбоев нет</div>');
  tip.innerHTML='<div class="d">'+d.label+'</div><div class="k">аптайм: <b style="color:'+uc+'">'+ut+'</b></div>'+down;
  tip.style.opacity="1";moveTip(e);
}
function showTipServer(e,s){
  var u=s.uptime30;
  var uc=(u===null)?"var(--tx2)":(u>=99.9?"var(--ok)":(u>=99?"var(--warn)":"var(--bad)"));
  var ut=(u===null)?"нет данных":u.toFixed(2)+"%";
  var dm=(s.downMin30>0)?'<b style="color:var(--bad)">'+fmtDur(s.downMin30)+'</b>':'<b style="color:var(--ok)">0 мин</b>';
  tip.innerHTML='<div class="d">'+escapeHtml(s.name)+'</div>'+
    '<div class="k">статус: '+(s.online?'<b style="color:var(--ok)">онлайн</b>':'<b style="color:var(--bad)">офлайн</b>')+'</div>'+
    '<div class="k">аптайм 30 дн: <b style="color:'+uc+'">'+ut+'</b></div>'+
    '<div class="k">общий простой: '+dm+'</div>';
  tip.style.opacity="1";moveTip(e);
}
var built=false,order=[],nodes={};
function updateTop(data){
  document.getElementById("title").textContent=data.title;
  document.title="Argent VPN"+(data.title?" — "+data.title:"");
  document.getElementById("subtitle").textContent=data.subtitle;
  var t=data.totals;
  var onlineEl=document.getElementById("s-online");
  var oh=t.online+" / "+t.total;
  if(t.maintenance&&t.maintenance>0)oh+=' <span class="vsub" title="'+t.maintenance+' на обслуживании">🛠 '+t.maintenance+'</span>';
  onlineEl.innerHTML=oh;
  document.getElementById("s-uptime").textContent=(t.uptime30===null?"—":t.uptime30.toFixed(2)+"%");
  var fresh=document.getElementById("s-fresh");
  if(fresh)fresh.textContent=data.lastCheckTs?localHM(data.lastCheckTs):(data.lastCheck||"—");
  var allUp=t.online===t.total&&t.total>0;
  var ov=document.getElementById("overall");
  ov.className="pill "+(allUp?"ok":"bad");
  ov.innerHTML='<span class="dot" style="background:currentColor"></span><span>'+
    (allUp?"Все активные серверы доступны":(t.total-t.online)+" сервер(ов) недоступно")+'</span>';
  document.getElementById("foot").textContent=
    (data.lastCheckTs?"последняя проверка "+localDateHM(data.lastCheckTs):(data.lastCheck?"последняя проверка "+data.lastCheck:"ожидание первой проверки"))+
    (data.pollInterval?" · обновление раз в "+Math.round(data.pollInterval/60*10)/10+" мин":"");
}
function srvUpColor(u){return (u===null)?"var(--tx2)":(u>=99.9?"var(--ok)":(u>=99?"var(--warn)":"var(--bad)"));}
function applyServer(item,s,days){
  item._label._s=s;
  item._dot.style.background=s.maintenance?"#2f8fff":(s.online?"#16b07a":"#e8504e");
  for(var i=0;i<item._bars.length;i++){var d=s.days[i];if(d){item._bars[i]._d=d;item._bars[i].setAttribute("fill",colorFor(d));}}
  if(s.maintenance){
    item._p.textContent="обслуж.";item._p.style.color="var(--info)";
    item._s2.textContent=(s.maintTo&&s.maintTo>0)?("≈ до "+localSmart(s.maintTo)):"идут работы";
  }else{
    item._p.textContent=(s.uptime30===null)?"—":s.uptime30.toFixed(2)+"%";
    item._p.style.color=srvUpColor(s.uptime30);
    item._s2.textContent=days+" дн"+(s.members>1?" · "+s.membersOnline+"/"+s.members+" узлов":"");
  }
}
function buildList(data){
  var list=document.getElementById("list");
  list.innerHTML="";nodes={};order=[];
  data.servers.forEach(function(s,idx){
    var item=document.createElement("div");item.className="item"+(s.maintenance?" maint":"");item._sid=s.sid;
    item.style.animationDelay=Math.min(idx*0.04,0.5)+"s";
    var row=document.createElement("div");row.className="row";
    var flag=s.cc?'<img class="flag" src="/flags/'+s.cc+'.svg" alt="" loading="lazy">':'<img class="flag" src="/flags/xx.svg" alt="" loading="lazy">';
    var label=document.createElement("div");label.className="label";
    label.innerHTML=flag+'<div class="nm"><div class="name"><span class="sdot"></span><span>'+escapeHtml(s.name)+'</span></div>'+(s.maintenance?'<div class="mnt-line">\uD83D\uDEE0 '+maintLabel(s)+'</div>':'')+'</div>';
    label._s=s;
    label.addEventListener("mouseenter",function(e){showTipServer(e,this._s);});
    label.addEventListener("mousemove",moveTip);
    label.addEventListener("mouseleave",hideTip);
    var N=s.days.length||1;
    var bars=document.createElementNS(SVGNS,"svg");bars.setAttribute("class","bars");
    bars.setAttribute("viewBox","0 0 1000 100");bars.setAttribute("preserveAspectRatio","none");
    var slot=1000/N,gap=Math.min(7,slot*0.32),barArr=[];
    s.days.forEach(function(d,i){
      var r=document.createElementNS(SVGNS,"rect");
      r.setAttribute("x",(i*slot+gap/2).toFixed(2));r.setAttribute("y","0");
      r.setAttribute("width",(slot-gap).toFixed(2));r.setAttribute("height","100");
      r.setAttribute("rx","7");r.setAttribute("fill",colorFor(d));r._d=d;
      r.addEventListener("mouseenter",function(e){showTipDay(e,this._d);});
      r.addEventListener("mousemove",moveTip);
      r.addEventListener("mouseleave",hideTip);
      bars.appendChild(r);barArr.push(r);
    });
    var st2=document.createElement("div");st2.className="stat2";
    var pEl=document.createElement("div");pEl.className="p";
    var sEl=document.createElement("div");sEl.className="s";
    st2.appendChild(pEl);st2.appendChild(sEl);
    row.appendChild(label);row.appendChild(bars);row.appendChild(st2);
    item.appendChild(row);
    item._dot=label.querySelector(".sdot");item._bars=barArr;item._p=pEl;item._s2=sEl;item._label=label;
    applyServer(item,s,data.days);
    list.appendChild(item);order.push(skey(s));nodes[s.sid]=item;
  });
  built=true;
}
function skey(s){return s.sid+"|"+(s.hidden?1:0)+(s.absent?1:0)+(s.maintenance?1:0);}
function sameOrder(data){
  if(!built||order.length!==data.servers.length)return false;
  for(var i=0;i<order.length;i++)if(order[i]!==skey(data.servers[i]))return false;
  return true;
}
var lastSeen=null;
function renderIncidents(data){
  var el=document.getElementById("incidents");if(!el)return;
  var incs=(data&&data.incidents)||[];
  if(!incs.length){el.innerHTML="";el.style.display="none";return;}
  el.style.display="";
  var sev={minor:"Незначительный",major:"Серьёзный",critical:"Критический"};
  var stt={investigating:"Расследуем",identified:"Причина найдена",monitoring:"Наблюдаем",resolved:"Устранён"};
  var html="";
  incs.forEach(function(i){var sv=i.severity||"minor";
    var started=i.startedTs?'<span class="inc-time">🕒 начат '+localSmart(i.startedTs)+'</span>':'';
    var aff='';
    if(i.affected&&i.affected.length){
      var ap=i.affected.map(function(a){
        if(typeof a==="string"){return escapeHtml(a);}
        var f=a.cc?'<img class="flag" src="/flags/'+a.cc+'.svg" alt="" loading="lazy">':'<img class="flag" src="/flags/xx.svg" alt="" loading="lazy">';
        return f+escapeHtml(a.name||"");
      });
      aff='<div class="inc-aff">🎯 затронуты: '+ap.join(", ")+'</div>';
    }
    var tl='';
    if(i.updates&&i.updates.length){
      tl='<div class="inc-tl">';
      i.updates.forEach(function(u){
        var body=(u.body&&u.body!=="статус обновлён")?' — '+escapeHtml(u.body):'';
        tl+='<div class="inc-tlrow"><span class="inc-tlt">'+localSmart(u.ts)+'</span><span class="inc-tls">'+escapeHtml(stt[u.status]||u.status||'')+'</span>'+body+'</div>';
      });
      tl+='</div>';
    }
    html+='<div class="inc-card inc-'+sv+'"><div class="inc-h"><span class="inc-sev">'+escapeHtml(sev[sv]||sv)+'</span><span class="inc-status">'+escapeHtml(stt[i.status]||i.status||"")+'</span>'+started+'</div><div class="inc-title">'+escapeHtml(i.title||"")+'</div>'+aff+tl+'</div>';});
  el.innerHTML=html;
}
function render(data){
  updateTop(data);
  renderIncidents(data);
  if(sameOrder(data)){
    data.servers.forEach(function(s){var item=nodes[s.sid];if(item)applyServer(item,s,data.days);});
  }else{

    buildList(data);
  }
}
function load(){
  fetch("api/summary").then(function(r){
    if(!r.ok)throw new Error("http "+r.status);
    return r.json();
  }).then(function(d){
    if(!d||!d.servers)throw new Error("bad payload");
    render(d);
  })
  .catch(function(){
    built=false;
    var list=document.getElementById("list");
    if(!list.querySelector(".item")){
      list.innerHTML='<div class="skel">Обновление не удалось — пробуем снова…</div>';
    }
  });
}
window.addEventListener("resize",function(){
  var ps=document.querySelectorAll(".item.open .panel");
  for(var i=0;i<ps.length;i++)ps[i].style.maxHeight=ps[i].scrollHeight+"px";
});
load();
setInterval(function(){if(!document.hidden)load();},60000);
document.addEventListener("visibilitychange",function(){if(!document.hidden)load();});
</script>
</body>
</html>
